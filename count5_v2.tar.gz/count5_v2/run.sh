#!/bin/bash
# count5_v2: exact counts of the uncounted five-ways and four-ways (151-300 digits) -- are any of them six-ways?
#   PASS=1 KIND=5  five-ways (1,546), 10 min limits per number, smallest first
#   PASS=1 KIND=4  four-ways (3,810), same
#   PASS=2         only the numbers pass 1 left unknown, 2 h limits, fewer processes (memory)
# Each start runs at most HOURS (default 14.5) and stops cleanly; starting again with the same settings resumes.
set -u
PASS=${PASS:-1}; KIND=${KIND:-5}; PROCS=${PROCS:-32}; HOURS=${HOURS:-14.5}
export PATH="$HOME/pari/bin:$PATH"
command -v gp > /dev/null || { echo "gp not found"; exit 1; }
D=$PWD; C=experiments/mining/count5/count_multi.py
echo "== pass $PASS kind $KIND start $(date), $PROCS processes, at most $HOURS h"
if [ "$PASS" = 1 ]; then
  timeout ${HOURS}h python3 -u $C --kind $KIND --mindig 151 --maxdig 300 --tlim 600 --tcount 600 --procs $PROCS \
    --out $D/counted_pass1_k$KIND.txt --skip $D/counted_pass1_k$KIND.txt
else
  cat $D/counted_pass1_k*.txt.unk > $D/pass2_todo.unk
  timeout ${HOURS}h python3 -u $C --kind both --mindig 151 --maxdig 300 --tlim 7200 --tcount 7200 --procs $PROCS \
    --only $D/pass2_todo.unk --out $D/counted_pass2.txt --skip $D/counted_pass2.txt
fi
rc=$?
if [ $rc -eq 124 ]; then echo "== stopped at the time limit $(date): start again with the same PASS/KIND to resume"
else echo "== pass $PASS kind $KIND finished (exit $rc) $(date)"; fi
